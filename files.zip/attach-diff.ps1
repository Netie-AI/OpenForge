# .cursor/hooks/attach-diff.ps1
# Cursor "stop" hook (beta API — verify still fires after each Cursor update,
# check Cursor Settings -> Hooks output channel / .cursor/hooks.log).
#
# Purpose: capture real git evidence at the end of every agent turn,
# independent of whether the agent's own prose includes a diff. This is the
# structural fix for "Cursor said it changed files but didn't paste the diff."

$stdin = [Console]::In.ReadToEnd()
try {
    $payload = $stdin | ConvertFrom-Json
    $convId = $payload.conversation_id
} catch {
    $convId = "unknown-session"
}

$logDir = ".cursor/hooks/session-evidence"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir "$convId.md"

$status = git status --short 2>&1
$diff = git diff 2>&1
$diffStat = git diff --stat 2>&1
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

$entry = @"
## Session evidence — $timestamp

### git status --short
``````
$status
``````

### git diff --stat
``````
$diffStat
``````

### git diff
``````diff
$diff
``````
"@

Add-Content -Path $logFile -Value $entry

# Echo to stdout in case the hook output is surfaced back into the transcript.
# If it isn't (beta behavior may vary), the log file at $logFile is the
# guaranteed source of truth — point Claude review at it directly.
Write-Output $entry
